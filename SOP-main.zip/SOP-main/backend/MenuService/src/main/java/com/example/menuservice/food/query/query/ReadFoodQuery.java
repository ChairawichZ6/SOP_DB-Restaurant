package com.example.menuservice.food.query.query;

public class ReadFoodQuery {
}
