package com.example.menuservice.course.query.query;

public class ReadCourseQuery {
}
