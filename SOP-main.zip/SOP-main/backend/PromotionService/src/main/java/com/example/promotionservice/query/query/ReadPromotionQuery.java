package com.example.promotionservice.query.query;

import org.springframework.stereotype.Service;

@Service
public class ReadPromotionQuery {
}
