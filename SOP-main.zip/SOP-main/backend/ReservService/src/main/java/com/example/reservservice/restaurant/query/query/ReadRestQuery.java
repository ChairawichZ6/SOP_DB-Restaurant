package com.example.reservservice.restaurant.query.query;

public class ReadRestQuery {
}
