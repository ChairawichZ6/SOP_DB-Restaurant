package com.example.reservservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservServiceApplication.class, args);
	}

}
