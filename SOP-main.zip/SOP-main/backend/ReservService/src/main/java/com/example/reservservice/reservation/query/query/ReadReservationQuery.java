package com.example.reservservice.reservation.query.query;

public class ReadReservationQuery {
}
