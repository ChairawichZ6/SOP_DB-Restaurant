package com.example.reservservice.table.query.query;

import lombok.Data;

import java.io.Serializable;

@Data
public class ReadSeatQuery implements Serializable {
    private String id;
}
