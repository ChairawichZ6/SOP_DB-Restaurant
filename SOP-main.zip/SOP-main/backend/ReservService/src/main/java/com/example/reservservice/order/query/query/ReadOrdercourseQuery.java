package com.example.reservservice.order.query.query;

public class ReadOrdercourseQuery {
}
