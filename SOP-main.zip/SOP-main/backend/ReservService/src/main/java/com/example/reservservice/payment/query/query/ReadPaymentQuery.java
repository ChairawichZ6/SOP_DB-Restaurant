package com.example.reservservice.payment.query.query;

public class ReadPaymentQuery {
}
