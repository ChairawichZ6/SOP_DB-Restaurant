package com.example.reservservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
