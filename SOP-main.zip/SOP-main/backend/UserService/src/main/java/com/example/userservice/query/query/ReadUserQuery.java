package com.example.userservice.query.query;

public class ReadUserQuery{
}
